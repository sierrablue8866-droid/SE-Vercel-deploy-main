"""Support for streaming audio to a WAV file"""

from __future__ import annotations

import typing

import circuitpython_typing

class AudioFileWriter:
    """Streams an audio source to a ``.wav`` file in the background.

    ``AudioFileWriter`` is the inverse of `audiocore.WaveFile`: rather than being
    an audio *source* played by an `audioio.AudioOut`, it is a *sink* that
    drives an audio source (a microphone, ``synthio``, or an ``audiofilters``/
    ``audiodelays``/``audiofreeverb``/``audiospeed`` effect chain) and writes
    the resulting PCM to a file as a WAV.

    Recording runs on a background pump paced to the source's real-time rate,
    so it does not block and does not require a Python read loop."""

    def __init__(self, file: typing.BinaryIO, *, buffer_size: int = 32768) -> None:
        """Create an ``AudioFileWriter`` that writes to ``file``.

        :param typing.BinaryIO file: An already-open writable binary stream
          (a file opened in ``"wb"`` mode, or an `io.BytesIO`). The stream must
          support seeking so the WAV header sizes can be patched when recording
          stops. ``AudioFileWriter`` does not close it; the caller owns it.
        :param int buffer_size: Size in bytes of the internal RAM ring that
          decouples file-write latency from the source. Larger values tolerate
          longer write stalls (e.g. a slow SD card) at the cost of RAM.
          Minimum valid value, and default, is ``512``. Must be at least the
          size of the source buffer.

        The audio format (sample rate, channel count, bit depth) is taken from
        the source at `play()` time, so there are no format arguments here.

        Recording synthio to SD::

          import time
          import synthio
          from audiofilewriter import AudioFileWriter
          import storage

          SAMPLE_RATE = 16000
          OUTPUT_PATH = "/sd/demo_file.wav"

          C_major_scale = [60, 62, 64, 65, 67, 69, 71, 72, 71, 69, 67, 65, 64, 62, 60]
          synth = synthio.Synthesizer(sample_rate=SAMPLE_RATE)

          with open(OUTPUT_PATH, "wb") as f:
              writer = AudioFileWriter(f)
              writer.play(synth)
              for note in C_major_scale:
                  synth.press(note)
                  time.sleep(0.1)
                  synth.release(note)
                  time.sleep(0.10)
              writer.stop()
          print("Done ->", OUTPUT_PATH)
        """
        ...

    def deinit(self) -> None:
        """Stops recording (patching the WAV header) and releases resources."""
        ...

    def __enter__(self) -> AudioFileWriter:
        """No-op used by Context Managers."""
        ...

    def __exit__(self) -> None:
        """Automatically deinitializes when exiting a context. See
        :ref:`lifetime-and-contextmanagers` for more info."""
        ...

    def play(self, sample: circuitpython_typing.AudioSample) -> None:
        """Begin recording ``sample`` to the file. Does not block.

        Writes a WAV header (in the format of ``sample``) and starts the
        background pump. ``sample`` must be an 8-bit or 16-bit mono or stereo
        audio source. Use `playing` to tell when a finite source has finished,
        or call `stop()` to end recording of a continuous source (e.g. a mic)."""
        ...

    def stop(self) -> None:
        """Stop recording, flush the RAM ring to the file, and patch the WAV
        header sizes. The file is left open for the caller to close."""
        ...
    playing: bool
    """True while recording is in progress. Becomes False on its own when a
    finite source finishes, or after `stop()`. (read-only)"""
