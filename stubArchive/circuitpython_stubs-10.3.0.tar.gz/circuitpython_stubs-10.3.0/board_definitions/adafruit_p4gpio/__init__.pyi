# SPDX-FileCopyrightText: 2024 Justin Myers
#
# SPDX-License-Identifier: MIT
"""
Board stub for Adafruit P4 GPIO
 - port: espressif
 - board_id: adafruit_p4gpio
 - NVM size: 8192
 - Included modules: _asyncio, _eve, _pixelmap, adafruit_bus_device, adafruit_pixelbuf, aesio, alarm, analogbufio, analogio, array, atexit, audiobusio, audiocore, audioi2sin, audiomixer, audiomp3, binascii, bitbangio, bitmapfilter, bitmaptools, board, builtins, builtins.pow3, busdisplay, busio, busio.SPI, busio.UART, codeop, collections, countio, digitalio, displayio, dualbank, epaperdisplay, errno, espidf, fontio, fourwire, framebufferio, frequencyio, getpass, gifio, hashlib, i2cdisplaybus, io, jpegio, json, keypad, keypad.KeyMatrix, keypad.Keys, keypad.ShiftRegisterKeys, keypad_demux, keypad_demux.DemuxKeyMatrix, locale, lvfontio, math, memorymap, microcontroller, mipidsi, msgpack, neopixel_write, nvm, onewireio, os, os.getenv, ps2io, pulseio, pwmio, rainbowio, random, re, rotaryio, rtc, sdcardio, sdioio, select, sharpdisplay, socketpool.socketpool.AF_INET6, storage, struct, supervisor, supervisor.get_setting, synthio, sys, terminalio, tilepalettemapper, time, touchio, traceback, ulab, usb_cdc, vectorio, warnings, watchdog, zlib
 - Frozen libraries: 
"""

# Imports
import busio
import microcontroller


# Board Info:
board_id: str


# Pins:
B1_0: microcontroller.Pin  # GPIO0
B1_1: microcontroller.Pin  # GPIO1
B1_2: microcontroller.Pin  # GPIO2
B1_3: microcontroller.Pin  # GPIO3
B1_4: microcontroller.Pin  # GPIO4
B1_5: microcontroller.Pin  # GPIO5
B1_6: microcontroller.Pin  # GPIO6
B1_7: microcontroller.Pin  # GPIO7
B2_0: microcontroller.Pin  # GPIO8
B2_1: microcontroller.Pin  # GPIO9
B2_2: microcontroller.Pin  # GPIO10
B2_3: microcontroller.Pin  # GPIO11
B2_4: microcontroller.Pin  # GPIO12
B2_5: microcontroller.Pin  # GPIO13
B2_6: microcontroller.Pin  # GPIO14
B2_7: microcontroller.Pin  # GPIO15
B3_0: microcontroller.Pin  # GPIO16
B3_1: microcontroller.Pin  # GPIO17
B3_2: microcontroller.Pin  # GPIO18
B3_3: microcontroller.Pin  # GPIO19
B3_4: microcontroller.Pin  # GPIO20
B3_5: microcontroller.Pin  # GPIO21
B3_6: microcontroller.Pin  # GPIO22
B3_7: microcontroller.Pin  # GPIO23
T3_0: microcontroller.Pin  # GPIO33
T3_1: microcontroller.Pin  # GPIO32
T3_2: microcontroller.Pin  # GPIO31
T3_3: microcontroller.Pin  # GPIO30
T3_4: microcontroller.Pin  # GPIO29
T3_5: microcontroller.Pin  # GPIO28
T3_6: microcontroller.Pin  # GPIO27
T3_7: microcontroller.Pin  # GPIO26
T2_0: microcontroller.Pin  # GPIO43
T2_1: microcontroller.Pin  # GPIO42
T2_2: microcontroller.Pin  # GPIO41
T2_3: microcontroller.Pin  # GPIO40
T2_4: microcontroller.Pin  # GPIO39
T2_5: microcontroller.Pin  # GPIO38
T2_6: microcontroller.Pin  # GPIO37
T2_7: microcontroller.Pin  # GPIO34
T1_0: microcontroller.Pin  # GPIO51
T1_1: microcontroller.Pin  # GPIO50
T1_2: microcontroller.Pin  # GPIO49
T1_3: microcontroller.Pin  # GPIO48
T1_4: microcontroller.Pin  # GPIO47
T1_5: microcontroller.Pin  # GPIO46
T1_6: microcontroller.Pin  # GPIO45
T1_7: microcontroller.Pin  # GPIO44
BOOT: microcontroller.Pin  # GPIO35
BUTTON: microcontroller.Pin  # GPIO35
NEOPIXEL: microcontroller.Pin  # GPIO52
SDA: microcontroller.Pin  # GPIO53
SCL: microcontroller.Pin  # GPIO54


# Members:
def I2C() -> busio.I2C:
    """Returns the `busio.I2C` object for the board's designated I2C bus(es).
    The object created is a singleton, and uses the default parameter values for `busio.I2C`.
    """


# Unmapped:
#   none
